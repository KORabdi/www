<?php
// source: C:\wamp\www\Semestralka\app\presenters/templates/Contact/default.latte

class Template15fa0c8ed3a17f2d4e531bd3958243f0 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('400b2069bd', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb4931d72e35_content')) { function _lb4931d72e35_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="col-md-7">
	<h1>Contact me</h1>
	<div class="lead">
	Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when
	</div>
	
	<hr>
	
	<p>twitter: <a href="https://twitter.com/KORabdiHS" target="_blank">@KORabdiHS</a></p>
	<p>facebook: <a href="https://www.facebook.com/Mr.Keyyy" target="_blank">Konstantin Kožokar</a></p>
	<p>github: <a href="https://github.com/KORabdi" target="_blank">KORabdi</a></p>
	
</div>
<?php
}}

//
// block scripts
//
if (!function_exists($_b->blocks['scripts'][] = '_lbf619651ae0_scripts')) { function _lbf619651ae0_scripts($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;Latte\Macros\BlockMacrosRuntime::callBlockParent($_b, 'scripts', get_defined_vars()) ;
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lbea79af757e_title')) { function _lbea79af757e_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>Contact<?php
}}

//
// block head
//
if (!function_exists($_b->blocks['head'][] = '_lbb4f06e8847_head')) { function _lbb4f06e8847_head($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start(function () {});}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars())  ?>

<?php call_user_func(reset($_b->blocks['scripts']), $_b, get_defined_vars())  ?>

<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>



<?php call_user_func(reset($_b->blocks['head']), $_b, get_defined_vars()) ; 
}}