<?php
// source: C:\wamp\www\Semestralka\app\presenters/templates/Twitch/default.latte

class Template68ef61f9c7fc5f851737b01f3acb9b39 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('8b530bed89', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb3ded463318_content')) { function _lb3ded463318_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="col-md-12">
	<h1>Twitch chat log</h1>
	<table id="tab" class="table">
		<caption>
			<button id="search" class="nojs btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
			<div class="nojsinverse row panel">
				<div class="col-md-12">
					<form id="searchForm" method="GET" action="./">
			          <div class="form-group">
			          	<input name="csrf-token" value="<?php echo Latte\Runtime\Filters::escapeHtml($csrf_token, ENT_COMPAT) ?>" type="hidden" class="form-control">
			            <label for="article-name" class="control-label">Name:</label>
			            <input placeholder="Put username here"  list="mylist" value="<?php echo Latte\Runtime\Filters::escapeHtml($name, ENT_COMPAT) ?>" name="name" type="text" class="form-control" id="twitch-name" autocomplete="off">
			            <datalist id="mylist">
						</datalist>
			          </div>
		              <div class="form-group nojs">
		              	<label for="article-name" class="control-label">Date:</label>
		                <div class='input-group date' id='datetimepicker1'>
		                    <input placeholder="Put date here" value="<?php echo Latte\Runtime\Filters::escapeHtml($date, ENT_COMPAT) ?>" name="date" type='text' class="form-control">
		                    <span class="input-group-addon">
		                        <span class="glyphicon glyphicon-calendar"></span>
		                    </span>
		                </div>
		              </div>
			          <div class="form-group">
			            <label for="message-text" class="control-label">Message:</label>
			            <input placeholder="Put message here" value="<?php echo Latte\Runtime\Filters::escapeHtml($message, ENT_COMPAT) ?>" name="message" type="text" class="form-control" id="message-text">
			          </div>
			          <div class="form-group">
			          	<input class="btn" value="Send" type="submit">
			          	<img id="loading" alt="loading" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/include/images/loading.gif">
			          </div>
			        </form>
				</div>
			</div>
		</caption>
		<thead>
			<tr>
				<th>#</th>
				<th>Name</th>
				<th>Message</th>
				<th>Date</th>
			</tr>
		</thead>
		<tbody>
<?php $iterations = 0; foreach ($chatmessages as $chatmessage) { ?>
			<tr>
				<th scope="row"><?php echo Latte\Runtime\Filters::escapeHtml($chatmessage['id'], ENT_NOQUOTES) ?></th>
				<td><?php echo Latte\Runtime\Filters::escapeHtml($chatmessage['name'], ENT_NOQUOTES) ?></td>
				<td><?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::escapeHtml($chatmessage['message'], ENT_NOQUOTES), ENT_NOQUOTES) ?></td>
				<td><?php echo Latte\Runtime\Filters::escapeHtml($chatmessage['date'], ENT_NOQUOTES) ?></td>
			</tr>
<?php $iterations++; } ?>
		</tbody>
	</table>

</div>
<?php
}}

//
// block scripts
//
if (!function_exists($_b->blocks['scripts'][] = '_lb16639288e0_scripts')) { function _lb16639288e0_scripts($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;Latte\Macros\BlockMacrosRuntime::callBlockParent($_b, 'scripts', get_defined_vars()) ?>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/js/twitch.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/include/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script> 
<script type="text/javascript">
    $(function () {
        $('#datetimepicker1').datetimepicker({
        format: 'YYYY-MM-DD HH:mm'
        });
    });
</script>
<?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb16422bb3a9_title')) { function _lb16422bb3a9_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>Twitch chat log<?php
}}

//
// block head
//
if (!function_exists($_b->blocks['head'][] = '_lbd86bca20d4_head')) { function _lbd86bca20d4_head($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><link rel="stylesheet" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/include/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/css/twitch.css">
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start(function () {});}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars())  ?>

<?php call_user_func(reset($_b->blocks['scripts']), $_b, get_defined_vars())  ?>

<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>


<?php call_user_func(reset($_b->blocks['head']), $_b, get_defined_vars()) ; 
}}