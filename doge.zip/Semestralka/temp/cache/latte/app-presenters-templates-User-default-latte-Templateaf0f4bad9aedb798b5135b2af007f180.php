<?php
// source: C:\wamp\www\Semestralka\app\presenters/templates/User/default.latte

class Templateaf0f4bad9aedb798b5135b2af007f180 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('2ff7135172', 'html')
;
// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIRuntime::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Login page | Shiba doge bot v0.1</title>

    <!-- Bootstrap -->
    <link href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/include/bootstrap-3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/css/style.css" rel="stylesheet">
	<link href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/css/blog.css" rel="stylesheet">
	<link href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/css/login.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
<?php $iterations = 0; foreach ($flashes as $flash) { ?>    <div<?php if ($_l->tmp = array_filter(array('flash', $flash->type))) echo ' class="', Latte\Runtime\Filters::escapeHtml(implode(" ", array_unique($_l->tmp)), ENT_COMPAT), '"' ?>
><?php echo Latte\Runtime\Filters::escapeHtml($flash->message, ENT_NOQUOTES) ?></div>
<?php $iterations++; } ?>
    <div class="container">
    	<div class="form-signin">
	    	<form class="box" method="post" action="login" id="signin">
	    	<h1 class="text-center">Sign in</h1>
	    	<p>
	    		<label class="sr-only">Name</label>
	    		<input name="csrf-token" value="<?php echo Latte\Runtime\Filters::escapeHtml($csrf_token, ENT_COMPAT) ?>" type="hidden" class="form-control">
	    		<input name="name" type="text" class="form-control" placeholder="Name" required autofocus\>
	    	</p>
	    	<p>
	    		<label class="sr-only">Password</label>
	    		<input name="password" type="password" class="form-control" placeholder="Password" required \>
	    		<label>New here? <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("User:register"), ENT_COMPAT) ?>
">Join to us!</a></label>
	    	</p>
	    	
	    	<button class="btn btn-primary btn-block" type="submit">Sign in</button>
	    	</form>
    	</div>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/include/bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/www/js/login.js"></script>
  </body>
</html><?php
}}