<?php
namespace App\Presenters;

use Nette;
use App\Model\GalleryModel;

class GalleryPresenter extends BasePresenter{
	
	private $galleryModel;
	private $admin = False;
	
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http, Nette\Security\User $user, Nette\Http\Session $session,Nette\Http\Response $response){
		parent::__construct($database, $http, $user, $session, $response);
		$this->galleryModel = new GalleryModel($database);
		$this->admin = $this->user->isInRole('admin');
	}

	public function startup(){
		parent::startup();
	}
	
	public function renderDefault(){
		//var_dump($this->galleryModel->getImages());
		//die();
		$this->template->images = $this->galleryModel->fetchAll();
		$this->template->admin = $this->admin;
	}

	protected function createComponentGalleryAdminControl()
	{
		$gallery = new \gallerynavControl($this->admin);
		return $gallery;
	}
	
	public function actionAdd(){
		if($this->admin){
			$file = $this->http->getFile('pic');
			$description = $this->http->getPost('description');
			$this->galleryModel->save($file,$description);
		}
		$this->redirect('Gallery:default');
	}
	
	public function actionRemove()
	{
		if($this->admin){
			$this->galleryModel->remove($this->http->getQuery('id'));
		}
		$this->redirect('Gallery:default');
	}
	
	public function actionEdit(){
		if($this->admin){
			$this->galleryModel->update(array(
					'id' => $this->http->getPost('id'),
					'description' => $this->http->getPost('description'),
			));
		}
		$this->redirect('Gallery:default');
	}
}