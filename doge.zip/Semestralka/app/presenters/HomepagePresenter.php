<?php

namespace App\Presenters;

use Nette;
use App\Model;
use App\Model\PostsModel;


class HomepagePresenter extends BasePresenter
{
	private $postModel;
	private $admin = False;
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http, Nette\Security\User $user, Nette\Http\Session $session,Nette\Http\Response $response){
		parent::__construct($database, $http, $user, $session,$response);
		$this->admin = $this->user->isInRole('admin');
		$this->postModel = new \App\Model\PostsModel($database);
	}
	
	public function endCalc (){
		return min(($this->offsetCalc() + $this->postModel->$limit), $this->postModel->total());
	}
	
	public function startCalc (){
		return $this->offsetCalc + 1;
	}
	
	public function renderDefault()
	{
		//$this->user->login('KORabdi', 's3EDoucD');
		//$this->user->logout();
		$this->template->posts = $this->postModel->fetchAll();
		$this->template->page = $this->getPage();
		$this->template->pages = $this->postModel->getPages();
		$this->template->showLabels = function($idPost){return $this->postModel->getLabels($idPost);};
		$this->template->admin = $this->admin;
	}
	
	public function actionRemove($post_id){
		$this->postModel->remove($post_id);
		$this->redirect('Homepage:default');
	}
	
	public function actionAdd(){
		if($this->admin){
			$this->postModel->insert(array(
					'title' => $this->http->getPost('title'),
					'body' => $this->http->getPost('body'),
					'date' => new \DateTime(),
					'hide' => 0
			),$this->http->getPost('labels'));
		}

		$this->redirect('Homepage:default');
	}
	
	public function actionEdit(){
		if($this->admin){
			$this->postModel->update(array(
					'id' => $this->http->getPost('id'),
					'title' => $this->http->getPost('title'),
					'body' => $this->http->getPost('body'),
					'hide' => 0
			),$this->http->getPost('labels'));
		}
	
		$this->redirect('Homepage:default');
	}
	
	protected function createComponentHomenav()
	{
		$nav = new \homenavControl($this->admin);
		return $nav;
	}
	
	public function getPage()
	{
		if($this->http->getQuery('page')){
			if(is_numeric($this->http->getQuery('page'))){
				if($this->http->getQuery('page') > $this->postModel->getPages()){ 
					return $this->postModel->getPages();
				}else{
					return $this->http->getQuery('page');
				}
			}else{
				return 1;
			}
		}else{
			return 1;
		}
	}

}
