<?php

namespace App\Presenters;

use Nette;
use Nette\Application\UI\Presenter;
use App\Model\ApiModel;
use Nette\Utils\DateTime;


/**
 * Base presenter for all application presenters.
 */
class BasePresenter extends Nette\Application\UI\Presenter
{
	protected $user;
	protected $http;
	protected $response;
	protected $apiModel;
	protected $session;
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http, Nette\Security\User $user, Nette\Http\Session $session, Nette\Http\Response $response){
		parent::__construct($database,$http,$user,$session,$response);
		$this->user = $user;
		$this->http = $http;
		$this->response = $response;
		$this->session = $session;
		$this->apiModel = new ApiModel($http,$this->response,$this->session);
	}
	
	protected function beforeRender(){
		parent::beforeRender();
		$this->apiModel->setCsrfToken();
		$this->template->csrf_token = $this->session->getSection('Csrf-token')->value;
	}
	
	protected function createComponentNavControl()
	{
		$nav = new \navControl($this->user->isLoggedIn(),$this->session);
		return $nav;
	}
	
}
