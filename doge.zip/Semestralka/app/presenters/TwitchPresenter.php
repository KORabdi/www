<?php
namespace App\Presenters;

use \Nette;
use App\Model\ChatModel;

class TwitchPresenter extends BasePresenter
{
	private $chatmodel;

	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http, Nette\Security\User $user, Nette\Http\Session $session, Nette\Http\Response $response){
		parent::__construct($database,$http,$user,$session,$response);
		$this->chatmodel = new ChatModel($database);
	}
	
	public function startup(){
		parent::startup();
		if(!$this->user->isLoggedIn()){
			$this->flashMessage('You need to log in to see this category.');
			$this->redirect('Homepage:default');
		}
	}
	
	public function renderDefault()
	{
		$this->template->chatmessages = $this->chatmodel->fetchall($this->search());
		$this->template->name = $this->http->getQuery('name');
		$this->template->message = $this->http->getQuery('message');
		$this->template->date = $this->http->getQuery('date');
	}
	
	public function search()
	{
		return array('name'=>$this->http->getQuery('name'),'message'=>$this->http->getQuery('message'),'date'=>$this->http->getQuery('date'));
	}
	
	public function actionJson(){
		try{
			$this->apiModel->checkCsrfToken();
		}catch(\Exception $e){
			$this->response->setCode(\Nette\Http\IResponse::S403_FORBIDDEN);
			$this->flashMessage($e->getMessage());
			$this->redirect('Homepage:default');
		}
		$a = $this->chatmodel->fetchall($this->search());
		$this->sendResponse( new \Nette\Application\Responses\JsonResponse($a) );
	}

	public function actionNamesJson(){
		try{
			$this->apiModel->checkCsrfToken();
		}catch(\Exception $e){
			$this->response->setCode(\Nette\Http\IResponse::S403_FORBIDDEN);
			$this->flashMessage($e->getMessage());
			$this->redirect('Homepage:default');
		}
		$a = $this->chatmodel->getNames($this->http->getQuery('name'));
		$this->sendResponse( new Nette\Application\Responses\JsonResponse( $a ) );
	}
}

