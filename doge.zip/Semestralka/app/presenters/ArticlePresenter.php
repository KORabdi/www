<?php

namespace App\Presenters;

use Nette;
use App\Model;

class ArticlePresenter extends BasePresenter
{
	private $postModel;
	private $commentsModel;
	private $articleId;
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http, Nette\Security\User $user, Nette\Http\Session $session, Nette\Http\Response $response)
	{
		parent::__construct($database, $http, $user, $session,$response);
		$this->postModel = new \App\Model\PostsModel($database);
		$this->commentsModel = new \App\Model\CommentsModel($database);
	}
	
	public function startup()
	{
		parent::startup();
		$postModel = $this->postModel->fetch($this->http->getQuery('articleId'));
		if(!$postModel){
			$this->redirect('Homepage:default');
		}
	}
	
	public function actionAddCommon(){
		try{
			$this->apiModel->checkCsrfToken();
		}catch(\Exception $e){
			die($e->getMessage());
		}
		if($this->http->getPost('commentSuc')){
			if(!$this->requestCheck()){
				return;
			}
			$this->commentsModel->insert(array(
					'post_id'=>$this->http->getQuery('articleId'),
					'body'=>$this->http->getPost('body'),
					'author'=>$this->http->getPost('author'),
					'email'=>$this->http->getPost('email'),
					'date'=> new \DateTime(),
			));
			$this->redirect('Article:default',$this->http->getQuery('articleId'));
		}
	}
	
	public function actionAdd(){
		if(!$this->user->isLoggedIn()){
			$this->flashMessage('You are not signed in');
			$this->redirect('Article:default',$this->http->getQuery('articleId'));
		}
		if($this->http->getPost('commentSuc')){
			if(!$this->requestCheck()){
				$this->redirect('Article:default',$this->http->getQuery('articleId'));
			}
			$this->commentsModel->insert(array(
					'post_id'=>$this->http->getQuery('articleId'),
					'body'=>$this->http->getPost('body'),
					'author'=>$this->user->getIdentity()->name,
					'email'=>$this->user->getIdentity()->email,
					'date'=> new \DateTime(),
			));
			$this->redirect('Article:default',$this->http->getQuery('articleId'));
		}
	}
	
	
	public function renderDefault($articleId)
	{
		$this->articleId = $articleId;
		$this->template->post = $this->postModel->fetch($this->http->getQuery('articleId'));
		$this->template->comments = $this->commentsModel->fetch($articleId);
		$this->template->counter = 0;
		$this->template->isLoggedIn = $this->user->isLoggedIn();
	}
	
	public function actionJson(){
		$a = $this->postModel->fetch($this->http->getQuery('articleId'));
		$this->sendResponse( new Nette\Application\Responses\JsonResponse( $a ) );
	}
	
	public function actionLabelsJson(){
		$a = $this->postModel->getLabels($this->http->getQuery('articleId'));
		$this->sendResponse( new Nette\Application\Responses\JsonResponse( $a ) );
	}
	
	private function requestCheck(){
		if (! \App\Model\FormValidModel::validate($this->http->getPost())){
			$this->flashMessage('Non valid input(turn on JS for more info)!');
			$this->redirect('Article:default',$this->http->getQuery('articleId'));
			return FALSE;
		}
		return TRUE;
	}
}
