<?php

namespace App\Presenters;

use Nette;
use App\Model;
use App\Model\PostsModel;


class ArchivePresenter extends BasePresenter
{
	
	private $postsModel;
	
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http,  Nette\Security\User $user,Nette\Http\Session $session,Nette\Http\Response $response){
		parent::__construct($database, $http, $user,$session,$response);
		$this->postsModel = new PostsModel($database);
	}

	public function startup(){
		parent::startup();
	}

	public function renderDefault()
	{
		$this->template->archives = $this->postsModel->fetchAllArchive();
	}

}
