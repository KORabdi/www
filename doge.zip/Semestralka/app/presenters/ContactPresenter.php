<?php

namespace App\Presenters;

use Nette;
use App\Model;


class ContactPresenter extends BasePresenter
{
	public function __construct(Nette\Database\Context $database, Nette\Http\Request $http,  Nette\Security\User $user, Nette\Http\Session $session,Nette\Http\Response $response){
		parent::__construct($database, $http, $user, $session,$response);
	}

	public function startup(){
		parent::startup();
	}

	public function renderDefault()
	{
		$this->template->anyVariable = 'any value';
	}

}
