<?php
namespace App\Model;

use Nette;

class FormValidModel
{
	public static function validate($input){
		foreach ($input as $in){
			if(strlen($in) < 3){
				return False;
			}
		}
		return True;
	}	
}
