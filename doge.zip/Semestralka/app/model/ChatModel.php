<?php
namespace App\Model;

use Nette;

class ChatModel
{
	private $database;
	public function __construct(Nette\Database\Context $database){
		$this->database = $database;
	}
	
	public function fetchAll($array=NULL)
	{
		$arr = array();
		if(!isset($array['message']) || $array['message']==""){
			$arr['message'] = " AND 1=1 ";
		}else{
			$arr['message'] = " AND `message` LIKE '%".$this->mres($array['message'])."%' ";
		}
		if(!isset($array['name']) || $array['name']==""){
			$arr['name'] = " AND 1=1 ";
		}else{
			$arr['name'] = " AND `name`='".strtolower($this->mres($array['name']))."' ";
		}
		if(!isset($array['date']) || $array['date']==""){
			$arr['date'] = " AND 1=1 ORDER BY date DESC, id DESC";
		}else{
			$date = new \DateTime($array['date']);
			$arr['date'] = " AND `date`>='".$this->mres($date->format("Y-m-d H:i"))."' ORDER BY date ASC, id ASC";
		}
		return $this->database->query("
				SELECT *
				FROM `chat`
				WHERE 1=1 ".implode(" ",$arr)."
				LIMIT 50
				")->fetchAll();
	}
// TODO: Upravit strukturu database	
// 	public function getNames()
// 	{
// 		$arr = $this->database->query("
// 				SELECT name
// 				FROM chat
// 				")->fetchAll();
// 		$toRet;
// 		foreach ($arr as $a){
// 			$toRet[] = $a['name']; 
// 		}
// 		return array_unique($toRet);
// 	}

	public function getNames($input){
		$input = $this->mres($input);
		if (!isset($input) ||  $input == ""){
			$input = "1=1";
		}else{
			$input = "`name` LIKE '".$input."%'";
		}
		return $this->database->query('
				SELECT `name`
				FROM `chat_users`
				WHERE '.$input.'
				LIMIT 5
				')->fetchAll();
	}
	
	
	public function search($keys)
	{
		return $this->database->query("
				SELECT *
				FROM `chat`
				WHERE ",$keys," AND name!='PING'
				ORDER BY date DESC
				LIMIT 50
				
				")->fetchAll();				
	}
	
	private function mres($value)
	{
		$search = array("\\",  "\x00", "\n",  "\r",  "'",  '"', "\x1a");
		$replace = array("\\\\","\\0","\\n", "\\r", "\'", '\"', "\\Z");
	
		return str_replace($search, $replace, $value);
	}
}