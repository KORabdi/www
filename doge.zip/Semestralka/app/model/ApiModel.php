<?php
namespace App\Model;

use Nette;


class ApiModel {
	
	private $http;
	private $session;
	private $response;
	
	public function __construct(Nette\Http\Request $http, Nette\Http\Response $response, Nette\Http\Session $session ){
		$this->http = $http;
		$this->response = $response;
		$this->session = $session;
	}
	
	public function checkCsrfToken(){
		$clientkey = $this->http->getPost('csrf-token') ? $this->http->getPost('csrf-token') : $this->http->getQuery('csrf-token');
		$serverkey = $this->session->getSection('Csrf-token')->value;
		if(!isset($clientkey) || !isset($serverkey)){
			throw new \Exception('Wrong token.');	
		}
		if($clientkey != $serverkey){
			throw new \Exception('Permission denied.');
		}
	}
	
	public function setCsrfToken(){
		$ses = $this->session->getSection('Csrf-token');
		$ses->setExpiration('1 hour');
		$ses->value = bin2hex(openssl_random_pseudo_bytes(16));
	}
}