<?php 
namespace App\Model;

use Nette;

class GalleryModel
{
	private $database;
	
	public function __construct(Nette\Database\Context $database){
		$this->database = $database;
	}
	
	public function fetchAll()
	{
		return $this->database->table('gallery')->where('hide',0)->fetchAll();
	}
	
	public function insert($data)
	{
		$this->database->query('
        	INSERT INTO `gallery`', $data
				);
	}
	
	public function remove($post_id)
	{
		return $this->database->query('
				UPDATE `gallery`
				SET `hide` = 1
				WHERE `id` = ',$post_id
				);
	}
	
	public function update($array){
		$this->database->query('
				UPDATE `gallery` SET ',$array,'WHERE id='.(int)$array['id']
				);
	}
	
	public function getImages(){
		$directory = BASEPATH."/www/images/gallery/small/";
		//print ($directory);
		$images = glob($directory . "*.{jpg,gif,png}", GLOB_BRACE);
		$return = array();
		foreach($images as $image)
			$return[] = basename($image);
		return $return;
	}
	
	public function save(Nette\Http\FileUpload $file, $description){
		if($file->isImage() and $file->isOk()) {
			$file_ext=strtolower(mb_substr($file->getSanitizedName(), strrpos($file->getSanitizedName(), ".")));
			$file_name = uniqid(rand(0,20), TRUE).$file_ext;
			$file->move(BASEPATH.'/www/images/gallery/'.$file_name);
			$this->insert(array(
					'name' => $file_name,
					'description' => $description,
					'hide' => 0,
					'date' => new \DateTime()
			));	
			$image = \Nette\Utils\Image::fromFile(BASEPATH.'/www/images/gallery/'.$file_name);
			if($image->getWidth() > $image->getHeight()) {
				$image->resize(140, NULL);
			}
			else {
				$image->resize(NULL, 140);
			}
			$image->sharpen();
			$image->save(BASEPATH.'/www/images/gallery/small/'.$file_name);
		}
	}
}