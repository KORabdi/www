<?php
namespace App\Model;

use Nette;

class CommentsModel
{
	private $database;
	public function __construct(Nette\Database\Context $database){
		$this->database = $database;
	}
	
	public function fetch($post_id)
	{
		return $this->database->table('comments')->where('post_id',$post_id);
	}
	
	public function fetchAll()
	{
		return $this->database->table('comments')->fetchAll();
	}
	
	public function total() 
	{ 
		return $this->database->table('comments')->count();
	}
	
	public function insert($data)
	{
		$this->database->table('comments')->insert($data);
	}
}