<?php

use Nette\Application\UI;

class navControl extends UI\Control
{
	private $status;
	private $session;
	private $security;

	public function __construct($status,Nette\Http\Session $session)
	{
		parent::__construct();
		$this->status = $status;
		$this->session = $session;
	}

	public function render()
	{
		$template = $this->template;
		$template->status = $this->status;
		$template->csrf_token = $this->session->getSection('Csrf-token')->value;
		$template->render(__DIR__ . '/NavControl.latte');
	}
}