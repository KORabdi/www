<?php
use Nette\Application\UI;

class gallerynavControl extends UI\Control
{
	private $status;

	public function __construct($status)
	{
		parent::__construct();
		$this->status = $status;
	}

	public function render()
	{
		$template = $this->template;
		$template->status = $this->status;
		$template->render(__DIR__ . '/AdminGalleryNavControl.latte');
	}
}